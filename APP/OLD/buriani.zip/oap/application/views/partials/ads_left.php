<!-- Compare Products -->
<div class="row sidebar-box blue">

    <div class="col-lg-12 col-md-12 col-sm-12">

     
        <div class="sidebar-box-content1">
            <img width="160" border="0" onload="" class="img_ad" alt="" src="https://s-media-cache-ak0.pinimg.com/736x/b2/7d/85/b27d85b41b69ddda088358211f387a89.jpg">
           
        </div>
    </div>

</div>


<div class="row sidebar-box">

    <div class="col-lg-12 col-md-12 col-sm-12 sidebar-carousel">

        <section class="sidebar-slider">
            <div class="sidebar-flexslider">
                <ul class="slides">
                    <li>
                        <a href="#"><img src="<?php echo base_url();?>img/sidebar-slide1.jpg" alt="Slide1"/></a>
                    </li>
                    <li>
                        <a href="#"><img src="<?php echo base_url();?>img/sidebar-slide2.jpg" alt="Slide1"/></a>
                    </li>
                    <li>
                        <a href="#"><img src="<?php echo base_url();?>img/sidebar-slide3.jpg" alt="Slide1"/></a>
                    </li>
                </ul>
            </div>
            <div class="slider-nav"></div>
        </section>
       

    </div>

</div>
<!-- /Carousel -->



