<div class="row sidebar-box purple">

    <div class="col-lg-12 col-md-12 col-sm-12">



        <div class="sidebar-box-content1"  style="style:fixed;">
           <img width="160" border="0" onload="" class="img_ad" alt="" src="https://tpc.googlesyndication.com/simgad/9261822258118665801">



        </div>

    </div>
    <!--div class="sidebar-box-content" style="
                     background: none !important;">
                    <ul>
                        <li><img width="160" height="600" border="0" class="img_ad" alt="" src="https://tpc.googlesyndication.com/simgad/10735621255266078168"></li>
                    </ul>
                </div-->
</div>
<!-- /Categories -->


<!-- Compare Products -->
<div class="row sidebar-box blue">

    <div class="col-lg-12 col-md-12 col-sm-12">

        <div class="sidebar-box-heading">
            <i class="icons icon-docs"></i>
            <h4>Sponsors</h4>
        </div>
        <div class="sidebar-box-content">
            <table class="compare-table">

                <tr>
                    <td class="product-thumbnail">Ad Space</td>

                </tr>



            </table>

        </div>
    </div>

</div>
