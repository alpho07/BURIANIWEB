<footer id="footer" class="row">

    <!-- Upper Footer -->
    <div class="col-lg-12 col-md-12 col-sm-12">

        <div id="upper-footer" class="no-border">

            <div class="row">

                <!-- Newsletter -->
      

        </div>

    </div>
    <!-- /Upper Footer -->


    <!-- Lower Footer -->
    <div class="col-lg-12 col-md-12 col-sm-12">

        <div id="lower-footer">

            <div class="row">

                <div class="col-lg-6 col-md-6 col-sm-6">
                    <p class="copyright">Copyright &copy; <?php echo date('Y')?> <a href="#">Company</a>. All Rights Reserved.</p>
                </div>

             

            </div>

        </div>

    </div>
    <!-- /Lower Footer -->

</footer>