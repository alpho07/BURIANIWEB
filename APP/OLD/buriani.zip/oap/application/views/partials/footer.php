    <script src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places&key=AIzaSyCX2JkDRJ9icWnebmRQffe8b2tOYSbu-Ho&region=KE"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<!-- JavaScript -->
<script src="<?php echo base_url(); ?>js/jquery.geocomplete.min.js"></script>
<script src="<?php echo base_url(); ?>js/modernizr.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.sticky.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.raty.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/tinynav.min.js"></script>

<!-- Scroll Bar -->
<script src="<?php echo base_url(); ?>js/perfect-scrollbar.min.js"></script>

<!-- Cloud Zoom -->
<script src="<?php echo base_url(); ?>js/zoomsl-3.0.min.js"></script>

<!-- FancyBox -->
<script src="<?php echo base_url(); ?>js/jquery.fancybox.pack.js"></script>

<!-- jQuery REVOLUTION Slider  -->
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.themepunch.revolution.min.js"></script>

<!-- FlexSlider -->
<script defer src="<?php echo base_url(); ?>js/flexslider.min.js"></script>
<script defer src="<?php echo base_url(); ?>js/sly.js"></script>

<!-- IOS Slider -->
<script src = "<?php echo base_url(); ?>js/jquery.iosslider.min.js"></script>

<!-- noUi Slider -->
<script src="<?php echo base_url(); ?>js/jquery.nouislider.min.js"></script>

<!-- Owl Carousel -->
<script src="<?php echo base_url(); ?>js/owl.carousel.min.js"></script>

<!-- Cloud Zoom -->
<script src="<?php echo base_url(); ?>js/zoomsl-3.0.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.plugin.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.maxlength.min.js"></script>
<script src="<?php echo base_url(); ?>js/tinymce/tinymce.min.js"></script>


<!-- SelectJS -->
<script src="<?php echo base_url(); ?>js/chosen.jquery.min.js" type="text/javascript"></script>

<!-- Main JS -->
<script defer src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>js/main-script.js"></script>
<script src="<?php echo base_url(); ?>twitter/jquery.tweet.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>js/notify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/zebra_dialog.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.storageapi.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/moments.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

